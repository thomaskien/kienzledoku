﻿# kienzledoku Server Installer 1.5

Eigenständiges Windows-Setup für die **Serverkomponenten** von Kienzledoku.
Es installiert eine eigene Ubuntu-24.04-WSL2-Umgebung mit Whisper large-v3,
pyannote Community-1, llama.cpp und Commander. Der Arbeitsplatzclient und
T2med bleiben separat. Vorhandene Linux-Installationen werden nicht angesprochen.

## Start

`dist/kienzledoku-Server-Installer-1.5.exe` unter Windows 11 x64 öffnen.
Alternativ das gleichnamige ZIP entpacken und die EXE darin starten.
Der Assistent nutzt Windows PowerShell 5.1 und Windows Forms; Python muss auf
Windows nicht vorinstalliert sein. Das Setup ist nicht digital signiert.

CPU-Virtualisierung (Intel VT-x beziehungsweise AMD SVM) muss im UEFI/BIOS
eingeschaltet sein. Für die eigene WSL-Umgebung sind ein beschreibbares lokales
Laufwerk, ausreichend Platz für die aktiven Modellkopien und zusätzliche
Laufzeitpakete erforderlich. Der Assistent prüft den verfügbaren Platz.

Die erste Auswahl lautet **Server installieren/reparieren** oder **nur Modelle
herunterladen**. Der reine Download benötigt weder WSL noch Administratorrechte.
Die erkannten Modellbestände werden sofort angezeigt. Diese schnelle Anzeige
prüft Vorhandensein und Größe; vor Übernahme folgt immer die volle Prüfsumme.

Der Hugging-Face-Read-Token ist im Eingabefeld ausdrücklich **sichtbar**. Er wird
geschützt im Benutzerprofil gespeichert und aus Protokollen ausgeschlossen.
Die Bedingungen des Modells `pyannote/speaker-diarization-community-1` müssen
vorher im zugehörigen Hugging-Face-Konto akzeptiert sein. Der Assistent prüft
den tatsächlichen Zugriff, nicht nur das Format des Tokens.

## Modelle und Grafikspeicher

| Modell | Seriell, volle GPU-Auslagerung | Parallel mit Audio geladen |
|---|---:|---:|
| Qwen3.5-9B Q4_K_M | 8 GiB VRAM | 16 GiB VRAM |
| Qwen3.5-9B Q6_K | 12 GiB VRAM | 20 GiB VRAM; 24-GB-Karte empfohlen |
| Qwen3.8-27B UD-Q4_K_M | 20 GiB VRAM; 24-GB-Karte empfohlen | Nicht freigegeben |

Beispielgrößen: RTX 2070 SUPER 8 GB für Q4 seriell; RTX 5060 Ti **16 GB**
für Q4 parallel geladen; RTX 3090 24 GB für Q6 parallel oder 27B seriell.
Die VRAM-Größe allein bestimmt nicht die Geschwindigkeit. CUDA 13 benötigt
Compute Capability mindestens 7.5 und einen passenden Windows-NVIDIA-Treiber.
Der Installer installiert ausschließlich das CUDA-Toolkit **innerhalb von WSL**,
keinen Linux-Grafiktreiber und keinen Windows-Grafiktreiber.

Alle Profile verwenden 32.768 Token Kontext, einen LLM-Slot und deaktiviertes
Thinking. **Parallel** bedeutet gleichzeitig geladen; es ist keine Zusage
beliebiger gleichzeitiger Inferenz oder mehrerer LLMs auf derselben GPU.
Immer nur das jeweils aktive LLM ist geladen. Bei mehreren installierten Modellen
wechselt Commander kontrolliert und kehrt zum gewählten Standardmodell zurück.

Bei automatisch gewähltem Betrieb bleiben Q4 ab 16 GiB und Q6 ab 20 GiB VRAM
parallel mit den Audiomodellen geladen. Kleinere geeignete GPUs nutzen seriellen
Betrieb. CPU-Offload-Sonderprofile und Strata gehören nicht zu diesem Paket.

## WSL-Speicher und Windows-Reserve

Diese Angaben sind **WSL-RAM**, nicht der Gesamtspeicher des Rechners:

| WSL-Obergrenze | Vorgesehene Verwendung |
|---|---|
| 16 GiB | Parallel geladene 9B-Modelle bei ausreichendem VRAM; seriell mit begrenztem LLM-Dateicache |
| 24 GiB | Empfehlung für seriell gecachtes 9B Q4 |
| 28 GiB | Mehr Cache-Reserve für seriell gecachtes 9B Q6 |
| 32 GiB | Empfehlung für seriell gecachtes 27B Q4 |

Standardmäßig bleiben die vorhandenen Audiomodellobjekte und geparkten Gewichte
im RAM. Der zusätzliche **Whisper-SSD-Sparmodus** entfernt den CT2-Gewichtscache
aus dem RAM und lädt ihn später wieder von SSD. Bei 27B und 16 GiB WSL ist dieser
Sparmodus verpflichtend, weil Audio vollständig im RAM unter diesem Budget nicht
nachgewiesen wurde. Bei Q4/Q6 ist er optional.

Die KI-Slice erhält ein gemeinsames RAM-Limit von WSL-Obergrenze minus 3 GiB
und verwendet keinen Swap. Der Rest ist als Reserve für Linux und Laufzeitcode
eingeplant. Die Windows-Auslagerung anderer Programme wird nicht verändert.

Der Assistent zeigt Gesamtspeicher, WSL-Obergrenze und verbleibendes Windows-Budget.
Mindestens ungefähr 4 GiB Reserve müssen für Windows eingeplant bleiben. Mehr Reserve
ist bei anderen parallel verwendeten Anwendungen sinnvoll. Mehr als 50 Prozent
des Gesamtspeichers können ausdrücklich für WSL eingestellt werden.

**WSL verwaltet das Limit benutzerweit über `.wslconfig`.** Andere Einstellungen
bleiben erhalten; eine bestehende Datei wird vor Änderungen gesichert. Laufende
andere WSL-Instanzen werden nicht beendet. Sie müssen vor einer Änderung geschlossen
werden. Die eigene Umgebung heißt `kienzledoku-server`; vorhandene andere
Distributionen werden nicht verwendet oder überschrieben.

Die Budgets sind aus Linux-Messungen abgeleitete Planungswerte. Eine erfolgreiche
Prüfung auf dem konkreten Windows-Rechner ist weiterhin erforderlich.

## Tragbare Modellablage und Netzlaufwerke

Das Modellarchiv liegt standardmäßig **neben der EXE im Unterverzeichnis `models`**:

```text
kienzledoku-Server-Installer-1.5.exe
models/
  9b-q4/Qwen_Qwen3.5-9B-Q4_K_M.gguf
  9b-q6/Qwen_Qwen3.5-9B-Q6_K.gguf
  27b-q4/Qwen3.8-27B-UD-Q4_K_M.gguf
  whisper/...
  pyannote/...
```

Das Ziel kann im Assistenten geändert werden. Zusätzliche Quellen lassen sich
zeilenweise angeben, einschließlich `\\Server\Freigabe\models`. GGUF-Dateien
werden auch aus flachen Modellverzeichnissen übernommen. Für Audio können die
jeweiligen vorhandenen Modell-/Snapshotverzeichnisse als eigene Quelle angegeben
werden. Die Prüfsummen verhindern Verwechslungen gleichnamiger Dateien.

Downloads verwenden fortsetzbare `.part`-Dateien und feste Modellrevisionen.
Große Gewichte werden mit SHA-256 geprüft; kleine unveränderte HF-Repositorydateien
zusätzlich mit ihrem veröffentlichten Git-Blob-Hash. Es werden nur ausgewählte LLMs
geladen. Die beiden Whisper-Darstellungen und pyannote werden immer vorbereitet.

Das Archiv kann auf weitere Rechner mitgenommen werden. Für den aktiven Betrieb
werden ausgewählte Modelle ins Linux-Dateisystem der eigenen WSL-Umgebung kopiert.
Damit ist der laufende Server nicht von einer Netzfreigabe abhängig. Das benötigt
Platz sowohl für das aufbewahrte Downloadarchiv als auch für die aktive Kopie.
Eine UNC-Zielablage oder ein zugeordnetes Netzlaufwerk wie `Z:` wird für den
WSL-Import zusätzlich lokal zwischengespeichert. Dafür wird der Platz für eine
weitere lokale Modellkopie geprüft; WSL muss das Netzlaufwerk nicht selbst mounten.
Für WSL, Python-Pakete und Buildwerkzeuge wird weiterhin Internet benötigt;
eine vollständig netzlose Installation ist nicht enthalten.

## Netzwerk und Zugang

Voreinstellung: **nur localhost**, `http://localhost:8185`.
Optional kann genau eine vorhandene IPv4-Adresse ausgewählt werden. Eine
Windows-Portweiterleitung öffnet den Server zusätzlich auf dieser Adresse.
Die Freigabe gilt für die ausgewählte IP, TCP 8185 und das lokale Subnetz.
Seit Version 1.5 gilt diese einzelne Regel für alle Windows-Netzwerkprofile
(`Any`), einschließlich „Öffentlich“. Das Windows-Netzwerkprofil bleibt erhalten;
die Firewall wird nicht global deaktiviert. Die eingerichtete Regel wird aus
dem aktiven Windows-Regelbestand zurückgelesen und auf Aktivierung und Profil
geprüft. Die lokalen HTTP-Prüfungen belegen die Erreichbarkeit auf dem
Serverrechner; der Zugriff von einem separaten Client ist zusätzlich zu prüfen.

Die Linux-API und alle internen KI-Backends bleiben an Loopback gebunden. Der
zusätzliche Windows-Endpunkt leitet ausschließlich zur lokalen API weiter.
Das funktioniert unabhängig davon, ob WSL mit NAT oder gespiegeltem Netzwerk läuft,
sofern Windows auf den lokalen WSL-Endpunkt zugreifen kann. Eine Änderung der
gewählten Netzwerk-IP erfordert erneutes Konfigurieren im Assistenten.

Der Server erzeugt einen eigenen Client-Zugangstoken. Serveradresse und dieser
Token erscheinen am Ende zur Übernahme in den separat installierten Client.
Der HF-Token ist davon unabhängig. Keine Clientdateien, URL-Handler oder
T2med-Installationen werden erstellt.

## Installation, Wiederaufnahme und Betrieb

WSL-Aktivierung und Netzwerkfreigabe verlangen gegebenenfalls Windows-UAC.
Die Installation gehört weiterhin dem aufrufenden Windows-Benutzer. Bei notwendigem
Neustart erscheint ein entsprechender Hinweis. Danach unter
**Startmenü → kienzledoku Server → Installation fortsetzen** weitermachen.
Alternativ dieselbe EXE erneut öffnen. Vollständig geprüfte Modelldateien und
abgeschlossene Paket-/Buildphasen werden wiederverwendet.
Die Fortsetzung ist manuell: Assistent öffnen, Einstellungen prüfen und „Jetzt
ausführen“ wählen. Seit 1.4 werden erfolgreiche Prüfsummen dauerhaft pro Datei
gespeichert. Unveränderte Dateien werden danach ohne erneutes vollständiges
Einlesen übernommen. Neue, veränderte und unvollständige Dateien sowie geänderte
Soll-Prüfsummen werden vollständig geprüft. Neue Kopien erhalten einen eigenen
Nachweis. Unter „Modelle auswählen“ lässt sich eine vollständige Neuprüfung
ausdrücklich anfordern. Beim ersten Lauf mit 1.4 ist einmal eine vollständige
Prüfung nötig, weil 1.3 noch keine passenden Dateimerkmale gespeichert hat.

Bereits aktivierte Windows-Komponenten und eine vorhandene moderne WSL-Version
werden wiederverwendet. Fehlt WSL, folgt die Installation ohne Standarddistribution,
danach die eigene Ubuntu-Umgebung. Falls der WSL-Bootstrap trotz installierter
Laufzeit einen Fehlercode zurückgibt, wird die tatsächliche Verfügbarkeit mit
`wsl --version` geprüft. Ohne erfolgreichen Versionsnachweis wird nicht fortgesetzt.

Die Installation kann CUDA-Toolkit, Torch-Pakete und einen GPU-spezifischen
llama.cpp-Build benötigen; der erste Lauf kann entsprechend länger dauern.
Das Fortschrittsfenster zeigt die aktuelle Phase und das laufende Protokoll.
Während eines laufenden Vorgangs ist Schließen im Assistenten gesperrt. Ein
externer Abbruch kann durch erneutes Ausführen repariert werden.

Startmenüeinträge: **Server starten**, **Server stoppen**, **Serverstatus**,
**Server prüfen**, **Installation fortsetzen**, **Server deinstallieren**.
Autostart ist wählbar und startet **nach der Anmeldung dieses Benutzers**.
Ein Start vor der Windows-Anmeldung ist nicht enthalten.

Eine an Windows angebundene eigene WSL-Sitzung hält die Instanz während des
Serverbetriebs am Leben. Beim Stoppen werden zuerst alle eigenen KI-Dienste
beendet und anschließend nur die eigene WSL-Instanz terminiert. Damit werden
auch deren RAM- und VRAM-Belegungen freigegeben. Andere WSL-Instanzen und
Windows-Grafikprozesse bleiben bestehen.

Am Ende ist der Server standardmäßig gestoppt; „eingeschaltet lassen“ ist wählbar.
Bei GPU-Wechsel auf einer portablen Windows-SSD den Installer erneut ausführen,
damit GPU-Profile und Buildarchitektur zur aktuellen Maschine passen.

Bei Deinstallation: eigene WSL-Umgebung samt aktiven Modellen entfernen **oder**
Server deaktivieren und vorbereitete Umgebung behalten. Modellarchive auf
SSD/Netzlaufwerk werden immer behalten. Eine spätere Wiederverwendung der
behaltenen Umgebung erfolgt über dieselbe Setup-EXE.

## Prüfstand dieser Ausgabe

Version **1.5** korrigiert die LAN-Freigabe bei öffentlichem Windows-Netzwerkprofil.
Auf dem Testrechner waren die Portweiterleitung und `/health` auf localhost
funktionsfähig, Ethernet aber als `Public` eingestuft. Die Regel aus 1.4 galt nur
für `Private,Domain`. Die Regel wird jetzt mit `Profile Any` und ausdrücklich
aktiviert angelegt; ihre Einschränkungen auf die ausgewählte IP, TCP 8185 und
`LocalSubnet` bleiben bestehen. Der administrative Installationsschritt übernimmt
dies automatisch. Anschließend wird die aktive Regel aus `ActiveStore` ausgelesen.
Die Prüfung vom Serverrechner wird im Protokoll als lokaler Test gekennzeichnet.

Für eine bereits installierte 1.4 ist die unmittelbare Korrektur in einer
**als Administrator geöffneten Windows-PowerShell** möglich:

```powershell
Set-NetFirewallRule -Name "kienzledoku-server-8185" -Profile Any
```

Ein Arbeitsverzeichnis `C:\Windows\system32` bedeutet nicht, dass die Konsole
erhöhte Rechte besitzt. „Windows System Error 5 / Zugriff verweigert“ beim
Ändern der Regel verlangt zuerst ein tatsächlich erhöhtes PowerShell-Fenster.

Version **1.4** hält das Installationsprotokoll auch auf der Ergebnisseite
sichtbar, bis der Assistent ausdrücklich geschlossen wird. „Ganzes Protokoll
öffnen“ zeigt die vollständige Datei. Pro Lauf bleiben zusätzliche Dateien
`engine-<Laufkennung>.stderr.log` und `.stdout.log` im Windows-Zustandsordner
`%LOCALAPPDATA%\kienzledoku-server` erhalten. `last-operation.json` verweist auf
diese Dateien. Der HF-Token wird in der angezeigten Fehlermeldung ausgelassen;
die zusätzlichen Prozessdateien erhalten dieselben privaten Zugriffsrechte wie
die Konfigurationsdateien.

Endet der Hintergrundprozess ohne Abschlussstatus, zeigt der Assistent nun
Exitcode (dezimal und hexadezimal), letzten Schritt und vorhandene Prozessausgaben.
`native-process.json` enthält den letzten externen Prozessaufruf. Erkannte
Programmfehler enthalten zusätzlich die letzten Programmausgaben. In WSL wird
bei Python-Fehlern `installation-error.json` mit Schritt, Befehl und Traceback
abgelegt. Ein unveränderter Fortschrittswert gilt nicht als Nachweis, dass ein
bereits beendeter Prozess noch läuft. Die Ursache des gemeldeten Abbruchs von
1.3 ist mit dem vorhandenen Protokoll noch nicht nachgewiesen.

Außerdem speichert 1.4 erfolgreiche Integritätsprüfungen von unveränderten
Modellen unter Windows und WSL. Die gespeicherten Nachweise gelten auch für
Whisper- und pyannote-Dateien. Die Abschlussprüfung der tatsächlichen Inferenz
ist davon unabhängig und bleibt auswählbar.

Version **1.3** korrigiert die eigentliche Ursache der wiederholten WSL-Abbrüche:
Die bisherige Prozessroutine setzte alle Argumente in Anführungszeichen.
Der WSL-Parser vergleicht Verwaltungsschalter jedoch als rohe Tokens; dadurch
wurde `"--version"` als Linux-Befehl behandelt und „keine installierten
Distributionen“ gemeldet. Nun werden nur leere Argumente und Werte mit Leerraum
oder Anführungszeichen geschützt. Schalter wie `--version`, `--import` und
`--distribution` bleiben unverändert. Pfade mit Leerzeichen bleiben geschützt.

Ein zusätzlicher Test kompiliert den unveränderten Funktionskörper von Microsofts
`ParseArgument` in einer portablen Testumgebung. Er reproduziert das vorherige
Fehlverhalten und prüft die tatsächlich erzeugten neuen Kommandozeilen. Das ist
eine Parserprüfung unter Linux, kein vollständiger Windows-/WSL-Test.
Quellen: [helpers.cpp](https://github.com/microsoft/WSL/blob/master/src/windows/common/helpers.cpp),
[WslClient.cpp](https://github.com/microsoft/WSL/blob/master/src/windows/common/WslClient.cpp).

WSL wird außerdem über den expliziten Windows-Systempfad aufgerufen. Die
Verwaltungsaufrufe und Installerversion stehen jetzt im Protokoll, damit eine
abweichende Befehlsübergabe oder veraltete Startverknüpfung sofort erkennbar ist.

Die WSL-Einrichtung prüft nach dem Bootstrap zusätzlich die erfolgreiche
WSL-Versionsausgabe; bereits vorhandenes WSL wird nicht erneut installiert.
Windows-Komponenten im Zustand „Neustart ausstehend“ lösen einen Neustarthinweis
aus. WSL-Verwaltungsausgaben werden als UTF-16LE gelesen; Linux-Programmausgaben
bleiben UTF-8. Ein benötigter Neustart ist ein eigener Status im Assistenten.
Neun gezielte Regressionstests bilden diese Abläufe mit simulierten Windows-
Antworten nach; die Zeichendekodierung wird mit einem echten lokalen Prozess geprüft.

Version **1.1** behebt den Abbruch mit „SeSecurityPrivilege“ beim Schützen der
Konfigurations- und Tokendateien. Statt `Set-Acl` schreibt die Routine nur die
geänderten Dateizugriffsrechte über die .NET-Dateischnittstelle. Eigentümer,
Gruppe und Auditregeln werden nicht angefasst. Lesen dürfen weiterhin nur
der aufrufende Benutzer, SYSTEM und Administratoren; das Ergebnis wird anhand
der tatsächlichen Dateizugriffsrechte überprüft. Für diesen Schritt sind keine
Administrator- oder Audit-Sonderrechte vorgesehen. Die WSL- und LAN-Einrichtung
fordert erforderliche Administratorrechte weiterhin gesondert an.

Die Korrektur aus Version 1.0.1 ist enthalten: Der Abbruch mit „ExpectedBytes /
System.Object[]“ unter Windows PowerShell 5.1 ist behoben. JSON-Modelllisten werden
ausdrücklich in einzelne Dateieinträge aufgelöst. Dies korrigiert auch die Audio-Bestandsanzeige und die
Berechnung benötigter Dateigrößen. Ein gezielter Test bildet das abweichende
5.1-Verhalten nach und reproduziert vor der Korrektur denselben Fehler.
Weitere Fehlerprotokolle enthalten außerdem Fehlerkennung und Skript-Aufrufstelle.

Zum Fortsetzen nach diesen Fehlern die **neue EXE 1.5** öffnen und dasselbe
Modellarchiv auswählen. Keine Deinstallation und kein Löschen der Modelle nötig.
Ein alter Startmenüeintrag kann noch die bisherigen Skripte starten; die neue EXE
aktualisiert sie bei „Server installieren/reparieren“.
Im Fenstertitel und in der Kopfzeile muss **1.5** stehen.

Lokal geprüft: Python-Serverregressionen, beide Betriebsarten, Rückkehr nach
Modellwechsel, Authentifizierung, Worker-Sockets, Integritätsprüfung, WSL-
Konfiguration, PowerShell-Syntax und realer kleiner HTTPS-Download mit Teildatei.
Die EXE wird mit NSIS auf Linux gebaut und anschließend entpackt auf Vollständigkeit
kontrolliert. Es wird beim Erstellen kein produktiver KI-Server installiert.

**Noch nicht ausgeführt:** Start der Windows-Oberfläche, WSL-Erstinstallation,
CUDA-Inferenz und LAN-/Autostartprüfung auf einem tatsächlichen Windows-Rechner.
Diese Tests folgen auf dem vom Benutzer vorbereiteten Windows-11-System.
Es gibt keine Behauptung, dass bereits alle Windows-Versionen praktisch geprüft seien.

Die integrierte Abschlussprüfung verarbeitet synthetische Sprache durch ASR,
Sprechertrennung und jedes ausgewählte LLM, prüft Rückkehr und Objektidentität,
Tokenpflicht sowie langen Kontext. Ein stiller Modellfallback gilt dabei als
Fehler. Bei abgewählter Abschlussprüfung wird keine erfolgreiche Inferenzprüfung
behauptet. Protokolle und Ergebnisse befinden sich unter
`%LOCALAPPDATA%\kienzledoku-server` und in WSL unter `/var/lib/kienzledoku-server`.

## Quellen und Build

Die zentrale Datei `VERSION` bestimmt EXE-/ZIP-Namen, Assistent und
Installationsnachweise. Benutzerfestlegung für weitere veröffentlichte Änderungen:
immer **+0.1**, also nach 1.5 zunächst 1.6, dann 1.7 usw.

`models.json`, `audio-files.json` und `ubuntu.json` enthalten feste Quellen,
Revisionen, Größen und Prüfsummen. Quellenherkunft: `evidence/source-provenance.json`.
Der Server basiert auf dem bestehenden lokalen Kienzledoku-Installer; Änderungen
für WSL, getrennte Paketierung und residenten Betrieb liegen ausschließlich hier.

Build mit Python 3 und NSIS 3:

```bash
python3 build/build.py --makensis /PFAD/ZU/makensis
```

Tests:

```bash
PYTHONPATH=linux/runtime:linux:tests python3 -m unittest discover -s tests -v
pwsh -NoProfile -File tests/test_core.ps1
pwsh -NoProfile -File tests/test_core.ps1 -Network
pwsh -NoProfile -File tests/test_json_compat.ps1
pwsh -NoProfile -File tests/test_wsl_bootstrap.ps1
pwsh -NoProfile -File tests/test_private_files.ps1
python3 build/test_wsl_parser.py --pwsh /PFAD/ZU/pwsh
```

Die endgültige Windows-Prüfung muss mit Windows PowerShell 5.1 und realer NVIDIA-
GPU erfolgen. PowerShell 7 unter Linux prüft hier die übertragbaren Kernfunktionen
und Syntax, ersetzt aber keine Windows-Ausführung.
Der zusätzliche Parsercheck benötigt Python 3, PowerShell und einen C++17-Compiler
(`g++`) auf dem Buildrechner; diese Werkzeuge sind keine Windows-Installationsvoraussetzung.
`test_private_files.ps1` prüft echte Dateiberechtigungen ausschließlich unter
Windows. Unter Linux meldet es ausdrücklich SKIP und zählt nicht als bestanden.
Unter Windows PowerShell 5.1 kann es mit `powershell.exe -NoProfile -File
tests\test_private_files.ps1 -RequireWindows` ohne Administratorrechte ausgeführt werden.
